### List

Cool bunch of useful functions for working with lists and for produce lists

*(c) Serge Gerasimov 2013*
