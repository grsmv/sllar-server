### erato

This is classical Sieve of Eratosthenes

*(c) Serge Gerasimov 2013*
